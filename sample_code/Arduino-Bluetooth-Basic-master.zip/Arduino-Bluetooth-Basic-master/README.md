# Arduino-Bluetooth-Basic
Control a LED using your smartphone via bluetooth
Download the app from here : http://goo.gl/PSXVoF
Website : https://igniteinnovateideas.wordpress.com
